<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book-collection</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.ts']); ?>
</head>
<body>
    <div id="app"></div>
</body>
</html><?php /**PATH C:\Users\Daniel\Documents\GitHub\Book-collection\book-collection\resources\views/welcome.blade.php ENDPATH**/ ?>